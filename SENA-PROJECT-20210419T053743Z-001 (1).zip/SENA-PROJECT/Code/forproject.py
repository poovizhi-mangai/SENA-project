#import regex
import re
import csv
      
    
#start process_tweet
def processTweet(text):
    
   # initializing hashtag_list variable
    hashtag_list = []
      
    # splitting the text into words
    for word in text.split():
          
        # checking the first charcter of every word
        if word[0] == '#':
              
            # adding the word to the hashtag_list
           
            myFile.write(word[0:])
            myFile.write(",")
       
#end

#Read the tweets one by one and process it
fp = open('farmersprotest.txt', 'r', encoding = 'utf8')
line = fp.readline()
myFile = open('myfile.txt', 'w' , encoding = 'utf8')

while line:
    processedTweet = processTweet(line)
    myFile.write("\n")
    print ('file added')
    line = fp.readline()
#end loop
fp.close()
